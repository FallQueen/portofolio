import streamlit as st
import re
import pandas as pd
from datetime import datetime
from fpdf import FPDF
from langchain_community.llms import Ollama
from langchain_core.prompts import PromptTemplate
from langchain.chains import LLMChain

# ====== KONFIGURASI HALAMAN ======
st.set_page_config(page_title="Simulasi Interview AI", page_icon="🤖")
st.title("Simulasi Interview Kerja di MATA CORPORATION")
st.caption("🤖 Menggunakan model: Meta LLaMA 3.2 3B Instruct via LangChain + Ollama")

# ====== SIDEBAR ======
with st.sidebar:
    st.markdown("### ⚙️ Konfigurasi")
    st.success("Model: LLaMA 3.2 3B via Ollama + LangChain")

# ====== MODEL VIA LANGCHAIN + OLLAMA ======
llm = Ollama(model="llama3.2:3b")

template = """
Kamu adalah pewawancara profesional berbahasa Indonesia untuk perusahaan fiktif bernama MATA CORPORATION.

Selalu gunakan Bahasa Indonesia dalam seluruh tanggapanmu.

Pertanyaan sebelumnya: {question}
Jawaban kandidat bernama {name}: {answer}

Posisi yang dilamar: {role}
Pertanyaan ke: {index} dari total 7

Tugasmu:
- Nilai jawaban dari skala 0 (sangat buruk) hingga 100 (sangat baik).
- Gunakan kriteria:
    - 0–39: Tidak relevan, ngawur, tidak menjawab pertanyaan.
    - 40–69: Relevan tapi kurang jelas atau kurang mendalam.
    - 70–100: Sangat relevan, jelas, dan meyakinkan.
- Deteksi jika jawaban kosong, "tidak tahu", atau tidak masuk akal.
- Berikan umpan balik profesional dan membangun.

Jika ini belum pertanyaan ke-7, berikan pertanyaan lanjutan yang relevan.
Jika ini pertanyaan ke-7, akhiri interview dengan ucapan terima kasih dan penutup yang sopan.

Jawabanmu HARUS mengikuti format:
Skor: [0-100]
Feedback: ...
Pertanyaan Selanjutnya: ...
"""

prompt = PromptTemplate(
    input_variables=["question", "answer", "role", "index", "name"],
    template=template
)

chain = LLMChain(llm=llm, prompt=prompt)

# ====== STATE ======
if "step" not in st.session_state: st.session_state.step = "init"
if "user_name" not in st.session_state: st.session_state.user_name = None
if "selected_role" not in st.session_state: st.session_state.selected_role = None
if "question_index" not in st.session_state: st.session_state.question_index = 1
if "chat_history" not in st.session_state: st.session_state.chat_history = []
if "evaluation_scores" not in st.session_state: st.session_state.evaluation_scores = []
if "last_question" not in st.session_state: st.session_state.last_question = None

# ====== EKSTRAKSI NAMA ======
def extract_name(text):
    patterns = [
        r"nama saya ([a-zA-Z\s]+)",
        r"saya ([a-zA-Z\s]+)",
        r"perkenalkan(?:,)? saya ([a-zA-Z\s]+)"
    ]
    for pattern in patterns:
        match = re.search(pattern, text.lower())
        if match:
            return match.group(1).strip().title()
    return None

# ====== CLEAN TEXT UNTUK PDF ======
def clean_text(text):
    if not isinstance(text, str):
        return ""
    return (text
        .replace("–", "-")
        .replace("—", "-")
        .replace("‘", "'")
        .replace("’", "'")
        .replace("“", '"')
        .replace("”", '"')
        .replace("…", "...")
        .replace("•", "-")
        .encode("latin-1", "replace")
        .decode("latin-1"))

# ====== GENERATE PDF ======
def generate_pdf(dataframe, user_name, final_status):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    pdf.cell(200, 10, txt=clean_text(f"Hasil Simulasi Interview - {user_name}"), ln=True, align="C")
    pdf.ln(10)

    for index, row in dataframe.iterrows():
        isi = (
            f"Pertanyaan {index}:\n"
            f"{row['pertanyaan']}\n"
            f"Jawaban: {row['jawaban']}\n"
            f"Skor: {row['skor']}/100\n"
            f"Feedback: {row['feedback']}\n"
            f"Status: {row['status']}\n"
        )
        pdf.multi_cell(0, 10, txt=clean_text(isi))
        pdf.ln(1)

    avg_score = dataframe["skor"].mean()
    pdf.set_font("Arial", "B", size=12)
    pdf.ln(5)
    pdf.cell(0, 10, txt=clean_text(f"Skor Rata-rata: {avg_score:.1f}/100"), ln=True)
    pdf.cell(0, 10, txt=f"Status Akhir: {final_status}", ln=True)

    return pdf.output(dest="S").encode("latin-1", errors="replace")

# ====== UI CHAT MULAI ======
with st.chat_message("assistant"):
    st.markdown("Halo! Siap untuk memulai interview?")

for chat in st.session_state.chat_history:
    with st.chat_message(chat["role"]):
        st.markdown(chat["message"])

user_input = st.chat_input("Ketik jawabanmu di sini...")

if user_input:
    with st.chat_message("user"):
        st.markdown(user_input)
    st.session_state.chat_history.append({"role": "user", "message": user_input})

    if st.session_state.step == "init":
        if any(k in user_input.lower() for k in ["belum", "tidak", "tips", "nanti", "ngga"]):
            response = (
                "Tidak masalah! Berikut beberapa tips sebelum interview:\n\n"
                "- Pahami deskripsi pekerjaan yang kamu lamar.\n"
                "- Siapkan contoh konkret dari pengalamanmu.\n"
                "- Latihan menjawab pertanyaan umum seperti 'Ceritakan tentang dirimu'.\n"
                "- Bersikap tenang dan percaya diri.\n\n"
                "Kalau sudah siap, silakan perkenalkan dirimu. Contoh: 'Nama saya Keivan'."
            )
        else:
            extracted_name = extract_name(user_input)
            if extracted_name:
                st.session_state.user_name = extracted_name
                response = f"Terima kasih {st.session_state.user_name}! Posisi apa yang kamu lamar? (contoh: Project Manager)"
                st.session_state.step = "role"
            else:
                response = "Silakan perkenalkan dirimu terlebih dahulu, contoh: 'Nama saya Keivan'."

    elif st.session_state.step == "role":
        st.session_state.selected_role = user_input.title()
        st.session_state.step = "interview"
        first_question = f"Mengapa kamu tertarik melamar sebagai {st.session_state.selected_role} di MATA CORPORATION?"
        st.session_state.last_question = first_question
        response = f"Terima kasih! Kita mulai ya.\n\n**Pertanyaan pertama:**\n{first_question}"

    elif st.session_state.step == "interview":
        idx = st.session_state.question_index
        result = chain.run(
            question=st.session_state.last_question,
            answer=user_input,
            role=st.session_state.selected_role,
            index=idx,
            name=st.session_state.user_name
        )

        skor_match = re.search(r"Skor:\s*(\d{1,3})", result)
        feedback_match = re.search(r"Feedback:\s*(.+?)(?=\nPertanyaan|$)", result, re.DOTALL)
        next_q_match = re.search(r"Pertanyaan Selanjutnya:\s*(.*)", result)

        score = int(skor_match.group(1)) if skor_match else 0
        score = max(0, min(score, 100))

        feedback = feedback_match.group(1).strip() if feedback_match else "Feedback tidak tersedia."

        if not next_q_match and idx < 7:
            next_question = f"Apa kekuatan utama yang kamu miliki untuk posisi {st.session_state.selected_role}?"
            feedback += "\n\n⚠️ Format model tidak sesuai, menggunakan pertanyaan default."
        elif next_q_match and idx < 7:
            next_question = next_q_match.group(1).strip()
        else:
            next_question = None

        status = "Accepted" if score >= 70 else "Rejected"

        st.session_state.evaluation_scores.append({
            "pertanyaan": st.session_state.last_question,
            "jawaban": user_input,
            "skor": score,
            "feedback": feedback,
            "status": status
        })

        if idx >= 7 or not next_question:
            st.session_state.step = "done"
            response = f"{feedback}\n\nInterview selesai! 🎉 Terima kasih {st.session_state.user_name} telah mengikuti simulasi ini."
        else:
            st.session_state.last_question = next_question
            st.session_state.question_index += 1
            response = f"{feedback}\n\n**Pertanyaan selanjutnya:**\n{next_question}"

    elif st.session_state.step == "done":
        response = "Simulasi telah selesai. Kamu bisa unduh hasilnya di bawah ini."

    with st.chat_message("assistant"):
        st.markdown(response)
    st.session_state.chat_history.append({"role": "assistant", "message": response})

# ====== RINGKASAN HASIL ======
if st.session_state.step == "done":
    st.subheader("📊 Ringkasan Evaluasi")
    df = pd.DataFrame(st.session_state.evaluation_scores)
    df.index += 1
    st.dataframe(df)

    avg_score = df["skor"].mean()
    final_status = "Accepted" if avg_score >= 70 else "Rejected"
    st.metric("Skor Rata-rata", f"{avg_score:.1f}/100", help="Minimal 70 untuk diterima")
    st.metric("Status Akhir", final_status)

    with st.expander("📤 Export hasil (CSV)"):
        csv_name = f"hasil_simulasi_{st.session_state.user_name}_{datetime.now().strftime('%Y%m%d%H%M')}.csv"
        st.download_button("Download CSV", df.to_csv(index=False).encode(), file_name=csv_name, mime="text/csv")

    with st.expander("📥 Export hasil (PDF) dan opsi ulangi"):
        pdf_data = generate_pdf(df, st.session_state.user_name, final_status)
        st.download_button("Download PDF", pdf_data, file_name=f"hasil_simulasi_{st.session_state.user_name}.pdf", mime="application/pdf")

        if st.button("🔁 Ulangi Simulasi"):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()
